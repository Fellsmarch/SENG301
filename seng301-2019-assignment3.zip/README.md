# seng301-assignment-3

To run the app:

Open the project from intellij by going file -> open -> seng301-2019-assignment3

1. Set java SDK to 1.8.

2. Set project language level to 8.

3. If necessary, right click the java folder -> Mark Directory as -> Sources Root.

4. If necessary, set the project output to the target folder. You might have to create on inside the seng301-2019-assignment3 folder.

5. Run the app from the Main function in the AdventureGame class.