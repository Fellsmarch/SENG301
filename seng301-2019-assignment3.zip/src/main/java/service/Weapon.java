package service;

public interface Weapon {
    /**
     * Attack method for a weapon.
     * @return String.
     */
    String swing();
}
