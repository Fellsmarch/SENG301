package service;

public interface Command {
    /**
     * Executes a particular command.
     */
    void execute();
}
